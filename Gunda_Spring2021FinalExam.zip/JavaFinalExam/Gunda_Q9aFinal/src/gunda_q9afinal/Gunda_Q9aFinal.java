/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q9afinal;

import java.io.IOException;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_Q9aFinal {

    /**
     * @param args the command line arguments
     */
        public static char a(String str) throws java.io.IOException
            
    {
        System.out.print(str+": ");
        return(char) System.in.read();
    }

    public static void main(String args[]) throws IOException 
    {
        
        char chr;
        
        try
        {
            chr= a("enter a letter");
        }
        catch(java.io.IOException ex)
        {
            System.out.println("IO Exception");
            chr='L';
        }
        System.out.println("Letter entered "+chr);
    }
    
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Math {
    
    int x = 16;
    int y = 5;

    void divide() {
        if (y == 5) {
            throw new ArithmeticException("cannot divide by 5");

        } else {
            int sol = x / y;
            System.out.println(sol);

        }
    }
    
}

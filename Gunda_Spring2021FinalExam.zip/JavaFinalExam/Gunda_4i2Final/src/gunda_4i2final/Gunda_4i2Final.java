/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_4i2final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_4i2Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Fruit fruit = new GoldenDelicious();
        Orange orange = new Orange();
        orange.makeOrangeJuice();
        /**
         * make line changes
         */
        if(fruit instanceof Orange){ 
            System.out.println("True");
        }
        else{
            System.out.println("False");
        }
    }
        
}
    class Fruit{
    }
    class Apple extends Fruit{
    }
    class Orange extends Fruit{
    public void makeOrangeJuice(){
    }
    }
    class GoldenDelicious extends Apple{
    }
    class McIntosh extends Apple{
    }

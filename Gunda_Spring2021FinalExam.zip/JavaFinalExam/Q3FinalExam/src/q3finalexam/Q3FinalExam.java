/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package q3finalexam;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Q3FinalExam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int intValue = 90;
    /**
     *Automatic casting from int value to double value
     */
                  
    double doubleValue = intValue; 
    /**
     * Assigning both int value 90 and double value 90.0
     */
    
    System.out.println(intValue);      
    System.out.println(doubleValue);  
  }
}

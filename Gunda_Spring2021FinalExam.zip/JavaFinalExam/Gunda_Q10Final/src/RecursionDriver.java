/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/**
 *
 * @author S542408
 */
public class RecursionDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Recursion10 rec = new Recursion10(10);
        int n;
        for (n = 0; n < 10; n++) {
            rec.values[n] = n;
        }
        rec.printArray(10);


    }
    
}

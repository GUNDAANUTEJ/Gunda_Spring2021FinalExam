/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q5final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         System.out.println("Question5: Gunda Sai Naga Anu Teja");
	ComparableCircle Cir1 = new ComparableCircle(6);
	ComparableCircle Cir2 = new ComparableCircle(18);
	System.out.println("Circle1: ");
	System.out.println(Cir1);
	System.out.println("Circle2: ");
	System.out.println(Cir2);
	System.out.println((Cir1.compareTo(Cir2) == 1 ? "Circle1 " : "Circle2") + " is the larger than two Circles");
    }
}
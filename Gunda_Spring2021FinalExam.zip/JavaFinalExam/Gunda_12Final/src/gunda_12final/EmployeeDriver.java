/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_12final;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
/**
 *
 * @author Gunda Sai Naga Anu Teja
 * 
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    ArrayList<Employee> q=new ArrayList<Employee>();
    q.add(new Employee(999,"Anu Tej",39000));    
    q.add(new Employee(566,"Ram",45000));
    q.add(new Employee(987,"Kishan",49000));
    q.add(new Employee(123,"Phani",40000));
    q.add(new Employee(765,"Munna",50000));
    System.out.println("Gunda Sai Naga Anu Teja");
    System.out.println("The original list is :");
        for(Employee srt:q){ 
            System.out.println(srt.toString()); 
	} 
    System.out.println("After the sorting with employee id :");
    Collections.sort(q);  
	for(Employee srt:q){  
            System.out.println(srt.toString());
	}  
    System.out.println("After sorting with salary :");
    Collections.sort(q,new Comparator<Employee>(){
    @Override
    public int compare(Employee arg0, Employee arg1) {
    return Double.compare(arg0.getEmpSalary(), arg1.getEmpSalary());
	}
        });
    for(Employee srt:q){  
	System.out.println(srt.toString());
	}  
    System.out.println("After sorting with employee name :");
    Collections.sort(q,new Comparator<Employee>(){
    @Override
    public int compare(Employee a1, Employee a2) {
    return a1.getEmpName().compareTo(a2.getEmpName());
        }
        });
    for(Employee srt:q){  
	System.out.println(srt.toString());
	}  

    }

}
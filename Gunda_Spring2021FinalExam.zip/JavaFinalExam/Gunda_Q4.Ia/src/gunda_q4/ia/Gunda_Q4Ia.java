/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q4.ia;

/**
 *
 * @author S542408
 */
public class Gunda_Q4Ia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
  Fruit fruit = new GoldenDelicious();
        Orange orange = new Orange();
        ((GoldenDelicious)fruit).makeAppleCider();//precedes casting
        if(fruit instanceof Orange){ //Change this line
            System.out.println("true");
        }else{
            System.out.println("false");
        }
    }
        
}
    class Fruit{}
    class Apple extends Fruit{
    public void makeAppleCider(){}
    }
    class Orange extends Fruit{}
    class GoldenDelicious extends Apple{}
    class McIntosh extends Apple{}

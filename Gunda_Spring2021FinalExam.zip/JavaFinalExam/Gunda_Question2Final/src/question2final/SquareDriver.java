/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2final;

/**
 *
 * @author S542408
 */
public class SquareDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Question2: Gunda Sai Naga Anu Teja");
        System.out.println("********************************************");
        Colorable column1 = new Square(10);
        Colorable column2 = new Square(20);
        Colorable column3 = new Square(30);
        Colorable column4 = new Square(40);
        Colorable column5 = new Square(50);
        GeometricObject[] objct = new GeometricObject[5];
        objct[0] = (GeometricObject) column1;
        objct[1] = (GeometricObject) column2;
        objct[2] = (GeometricObject) column3;
        objct[3] = (GeometricObject) column4;
        objct[4] = (GeometricObject) column5;

        
        for (GeometricObject geoObjFor : objct) {
            System.out.println("Area of Square is: " +geoObjFor.squareArea());
            geoObjFor.howToColor();
        }

    }

}


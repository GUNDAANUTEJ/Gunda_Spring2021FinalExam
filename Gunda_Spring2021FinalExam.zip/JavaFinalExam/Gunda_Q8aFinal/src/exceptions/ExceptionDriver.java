/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 *
 * @author S542408
 */
public class ExceptionDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ExceptionDriver eD = new ExceptionDriver();
        try{
            eD.minBal(1000);
        }
        catch(FindException f){
            System.out.println("Find Exception");
        }
        catch(ErrorException e){
            System.out.println("ErrorException");
        }
    }
    
     public void minBal(double amount) throws FindException, ErrorException {
      // multiple method is implementating
       if(amount < 1000)
        throw new FindException();
     else
        throw new ErrorException();
      
   }
    
       }
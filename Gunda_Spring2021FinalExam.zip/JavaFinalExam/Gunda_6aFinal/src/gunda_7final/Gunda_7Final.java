/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_7final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_7Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int value1=9;
	int value2=0;
	
	int result=num1/num2;
	System.out.println(result);
   }
}
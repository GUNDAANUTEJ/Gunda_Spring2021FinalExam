/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q11final;

import java.util.Objects;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 * class name Laptop
 */
public class Laptop {
    /**
     * datatype String instance attributes brandName and modelName in class Laptop
     * datatype int instance attribute cost in class Laptop
     */
     String brandName;
     String modelName;
     int cost;
     /**
     * Assigning the constructor to the above instance attributes
     */
     
    public Laptop(String brandName, String modelName, int cost) {
        this.brandName = brandName;
        this.modelName = modelName;
        this.cost = cost;
    }
    
    /**
     * Assigning get method to brandName
     */

    public String getBrandName() {
        return brandName;
    }
    
    /**
     * Assigning set method to brandName
     */

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    
    /**
     * Assigning get method to modelName
     */

    public String getModelName() {
        return modelName;
    }
    
    /**
     * Assigning set method to modelName
     */

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }
    
    /**
     * Assigning get method to cost
     */

    public int getCost() {
        return cost;
    }
    
    /**
     * Assigning set method to cost
     */

    public void setCost(int cost) {
        this.cost = cost;
    }
    
    /**
     * overriding the method
     * Assigning values to HashCode to int type
     */
     
     @Override
     public int hashCode() {
         int val = 3;
         val = 99 * val + Objects.hashCode(this.brandName) ;
         val = 99 * val + Objects.hashCode(this.modelName) ;
         val = 99 * val + this.cost ;
         return val ;
     }
     
     /**
     * overriding the method
     * Assigning values to equals using boolean type for brand name, model name and cost using java 
       inbuilt method for object
     */
     
     @Override
    public boolean equals(Object objct) {
        
        if (this == objct) {
            return true;
        }
        if (objct == null) {
            return false;
        }
        if (getClass() != objct.getClass()) {
            return false;
        }
        final Laptop other = (Laptop) objct;
        if (this.cost != other.cost) {
            return false;
        }
        if (!Objects.equals(this.brandName, other.brandName)) {
            return false;
        }
        if (!Objects.equals(this.modelName, other.modelName)) {
            return false;
        }
        return true;
    }
    
    
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q11final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 * creating the laptop driver class for the laptop class
 */
public class LaptopDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /**
         * Assigning four values to the laptop class attributes 
         */
        
        Laptop LP1=new Laptop("HP","Ptron", 92000);
        Laptop LP2=new Laptop("Apple","Macbook" , 105000);
        Laptop LP3=new Laptop("Lenovo", "Thinkpad", 60000);
        Laptop LP4=new Laptop("Dell", "Latitude", 75000);
        
        /**
         * printing values to the laptop instances using equals() method 
         */
        
        System.out.println("--------------------Equals--------------------");
        System.out.println(LP2.equals(LP2));
        System.out.println(LP2.equals(LP3));
        System.out.println(LP4.equals(LP2));
        System.out.println(LP3.equals(LP1));
        
        /**
         * printing values to the laptop instances using hashCode() method 
         */
        
        System.out.println("--------------------HashCode--------------------");
        System.out.println(LP1.hashCode());
        System.out.println(LP2.hashCode());
        System.out.println(LP3.hashCode());
        System.out.println(LP4.hashCode());
 
    }
    
}

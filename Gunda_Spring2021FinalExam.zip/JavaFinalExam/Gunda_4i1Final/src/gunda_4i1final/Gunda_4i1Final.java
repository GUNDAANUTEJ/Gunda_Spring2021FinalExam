/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_4i1final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_4i1Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Fruit fruit = new GoldenDelicious();
        Orange orange = new Orange();
    /**
     * precedes casting
     */
        ((GoldenDelicious)fruit).makeAppleCider();
        /**
         * making line changes
         */
        if(fruit instanceof Orange){ 
            System.out.println("True");
        }else{
            System.out.println("False");
        }
    }
        
}
    class Fruit{}
    class Apple extends Fruit{
    public void makeAppleCider(){}
    }
    class Orange extends Fruit{}
    class GoldenDelicious extends Apple{}
    class McIntosh extends Apple{}
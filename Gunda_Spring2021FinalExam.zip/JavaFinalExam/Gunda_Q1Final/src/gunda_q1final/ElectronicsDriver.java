/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q1final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class ElectronicsDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Question 1 : Gunda Sai Naga Anu Teja");
      Mobile m = new Mobile( "Neexus", 20000, "touch screen");
      m.BrandOfMobile();
      System.out.println("*****************");
      m.Cost();
        System.out.println("****************");
      m.Type();

    }
    
}

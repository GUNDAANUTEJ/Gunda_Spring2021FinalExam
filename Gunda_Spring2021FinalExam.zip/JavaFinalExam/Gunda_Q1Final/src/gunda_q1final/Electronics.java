/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q1final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public abstract class Electronics {
     private String Brand;
    private double Cost;
    private String type ;

    public Electronics(String Brand, double Cost, String type) {
        this.Brand = Brand;
        this.Cost = Cost;
        this.type = type;
    }

    public String getBrand() {
        return Brand;
    }

    public double getCost() {
        return Cost;
    }

    public String getType() {
        return type;
    }
    
}

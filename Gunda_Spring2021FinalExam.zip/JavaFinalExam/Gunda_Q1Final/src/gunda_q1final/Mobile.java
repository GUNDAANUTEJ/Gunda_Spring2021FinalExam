/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q1final;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Mobile extends Electronics {
        public Mobile(String Brand, double Cost, String Type) {
        super(Brand, Cost, Type);
    }

    public void BrandOfMobile()
    {
        System.out.println("The Moile Brand is Nexus");
    } 
    public void Cost() { 
        System.out.print("Cost of the Mobile is : ");
        System.out.println(super.getCost());
    }
    public void Type(){
        System.out.print("Type of the Mobile is : ");
        System.out.println(super.getType());  
    }  
  
    }



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_7afinal;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_7aFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
	   int arr[] ={1,2,3,4,5,6};
	   System.out.println(arr[9]);
	}
        catch(ArrayIndexOutOfBoundsException e){
	   System.out.println("Array does not consists of index. Need to solve the error.");
	}
   }
}

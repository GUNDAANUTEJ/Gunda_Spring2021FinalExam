/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_7final;
import java.util.*;
/**
 *
 * @author S542408
 */
public class Gunda_7Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Create a Scanner
		Scanner value = new Scanner(System.in);

		// use the getArray method
		int[] array = getArray();

		// User enters the index of the array
		System.out.print("Enter the index of the array: ");
		try {
			// Displaying the corresponding element value
			System.out.println("Corresponding Element value is " + array[value.nextInt()]);
		}
		catch (ArrayIndexOutOfBoundsException ex) {
                    System.out.println("The message Out of Bounds");
		}
	}

	/** An array with 100 randomly chosen integers.
         * @return  */
	public static int[] getArray() {
		int[] array = new int[100];
		for (int i = 0; i < array.length; i++) {
			array[i] = (int)(Math.random() * 100) + 1;
		}
		return array;
	}
}
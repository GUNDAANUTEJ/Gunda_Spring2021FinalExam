/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_6checkedfinal;
import java.io.*;
/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class Gunda_6checkedFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        	FileInputStream fist = null;
	
        fist = new FileInputStream("file.txt"); 
	int k; 
	while(( k = fist.read() ) != -1) 
	{ 
		System.out.print((char)k); 
	} 
	fist.close(); 	
   }
}


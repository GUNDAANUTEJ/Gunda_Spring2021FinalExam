/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q1afinal;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public class DriverClass implements Class1, Class2 {
        
    @Override
    public String getManual() {
        
// we have to provide implementation

return Class1.super.getManual() + Class1.super.getManual();
}
public static void main(String[] args) {
DriverClass  r = new DriverClass ();
System.out.println("Question 1 : Gunda Sai Naga Anu Teja");
System.out.println( r.getManual() ); // Prints "mp"
System.out.println( ((Class1)r).getManual() ); // Prints "mp"
System.out.println( ((Class2)r).getManual() ); // Prints "mp"

        
    }

  
}

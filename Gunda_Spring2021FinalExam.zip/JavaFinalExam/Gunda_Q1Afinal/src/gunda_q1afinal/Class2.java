/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunda_q1afinal;

/**
 *
 * @author Gunda Sai Naga Anu Teja
 */
public interface Class2 {
    public default String getManual(){
    return "p";

    }
}
